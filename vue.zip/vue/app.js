'use strict';

var config = {
    apiKey: "AIzaSyC5UQSKf6KV6YgAMMVOHvbUBpi9_fYtp0k",
    authDomain: "todoapp-daba5.firebaseapp.com",
    databaseURL: "https://todoapp-daba5.firebaseio.com",
    storageBucket: "todoapp-daba5.appspot.com",
    messagingSenderId: "696647795826"
};
var firebaseApp = firebase.initializeApp(config);
var db = firebaseApp.database();
console.log(db.ref('todoapp-daba5'));
new Vue({
    el: '#events',
    firebase: {
        items: db.ref('todoapp')
    },

    // Here we can register any values or collections that hold data
    // for the application
    data: {
        name: '',
        peoples: []
    },

    methods: {
        addName: function() {
            var name = this.name.trim();
            if (name) {
                this.peoples.push({
                    name: name
                });
                this.$firebaseRefs.items.push({
                  text: name
                });
                this.name = '';
            }
        },
        removeName: function(index) {
            this.peoples.splice(this.peoples.indexOf(index), 1);
        }
    }

});
